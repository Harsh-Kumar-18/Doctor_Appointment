import validator from "validator";
import bcrypt from "bcrypt";
import imagekit from "../config/imageKit.js";
import fs from "fs";
import doctorModel from "../models/doctorModel.js";

const addDoctor = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
      speciality,
      degree,
      experience,
      about,
      fees,
      address,
    } = req.body;
    const imageFile = req.file;

    if (
      !name ||
      !email ||
      !password ||
      !speciality ||
      !degree ||
      !experience ||
      !about ||
      !fees ||
      !address
    ) {
      return res.json({ success: false, message: "Missing Details" });
    }

    if (!validator.isEmail(email)) {
      return res.json({ success: false, message: "Enter a valid email" });
    }

    if (password.length < 8) {
      return res.json({ success: false, message: "Enter strong password" });
    }

    if (!imageFile) {
      return res.json({ success: false, message: "Image is required" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(password, salt);

    const fileBuffer = fs.readFileSync(imageFile.path);

const response = await imagekit.upload({
  file: fileBuffer,
  fileName: imageFile.filename,
});

const imageUrl = response.url;

fs.unlinkSync(imageFile.path);

    
    const doctorData = {
      name,
      email,
      image: imageUrl,
      password: hashPassword,
      speciality,
      degree,
      experience,
      about,
      fees,
      address: typeof address === "string" ? JSON.parse(address) : address,
      date: Date.now(),
    };

    const newDoctor = new doctorModel(doctorData);
    await newDoctor.save();

    res.json({ success: true, message: "Doctor Added" });
  } catch (error) {
    console.log("FULL ERROR:", JSON.stringify(error, null, 2));
    res.json({
      success: false,
      message: error.message || JSON.stringify(error),
    });
  }
};

export { addDoctor };
