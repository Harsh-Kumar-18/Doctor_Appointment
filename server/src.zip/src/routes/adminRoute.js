import express from "express";
import {
  addDoctor,
  allDoctors,
  loginAdmin,
  adminAppointments,
  appointmentCancel,
  adminDashboard,
} from "../controllers/adminController.js";
import upload from "../middleware/multer.js";
import authAdmin from "../middleware/authAdmin.js";
import { changeAvailability } from "../controllers/docController.js";

const adminRouter = express.Router();

adminRouter.post("/add-doctor", authAdmin, upload.single("image"), addDoctor);
adminRouter.post("/login", loginAdmin);
adminRouter.post("/all-doctors", authAdmin, allDoctors);
adminRouter.post("/change-availability", authAdmin, changeAvailability);
adminRouter.get("/dashboard", authAdmin, adminDashboard);
adminRouter.get("/admin-appointments", authAdmin, adminAppointments);
adminRouter.post("/cancel-appointment", authAdmin, appointmentCancel);

export default adminRouter;
